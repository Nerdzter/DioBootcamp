package ati.edu.nayderson.exercicio;
/* 
    public class SmartTv {

    booleanligada=false;
    intcanal=1;
    intvolume=25;

    public static void main(String[] args) throws Exception {
        SmartTv = new SmartTv();

        // Testando os métodos
        tv.ligar();
        System.out.println("TV ligada: " + tv.ligada);

        tv.desligar();
        System.out.println("TV ligada: " + tv.ligada);
    }

    // Método para ligar a TVpublicvoidligar() {
        ligada = true;
    }

    // Método para desligar a TVpublicvoiddesligar() {
        ligada = false;
    } */


    // O  CODIGO ACIMA ESTÁ  ERRADO POREM FOI FEITO UMA CORREÇÃO
}
