package ati.edu.nayderson.exercicio;
public class Usuario {
/* 
    public static void main(String [] args) throws Exception {
        
        
        SmartTv smartTv = new SmartTv();

        System.out.println("Tv está ligada? " + smartTv.ligada);
        System.out.println("Em qual canal a Tv está? " + smartTv.canal);
        System.out.println("Em qual volume a Tv está? " + smartTv.volume);
    
        smartTv.ligar();

        System.out.println("Novo status - > Tv está ligada? " + smartTv.ligada);
 
     */
    
    // O CODIGO ACIMA ESTÁ ERRADO MAS FOI FEITO UMA CORRECAO

}