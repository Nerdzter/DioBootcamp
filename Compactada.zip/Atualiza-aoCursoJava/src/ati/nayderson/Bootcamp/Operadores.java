package ati.nayderson.Bootcamp;

public class Operadores {
    public static void main(String[] args) {
        // operadores

        // Aritiméticos 

        /*
              Somente o básico mesmo     -> + - / *  
              Depois os mais "avançados" -> == != > <  <= >= % 
         */


         /*
             + positivo
             - negativo
             ++ acrescenta
             -- diminui 
          */

          int num = 5;

          System.out.println(num);

          num = num--;

          System.out.println(num);

          num = num++;

          System.out.println(num);

          // Ternário ? : if else   if? :else 


    }
}
