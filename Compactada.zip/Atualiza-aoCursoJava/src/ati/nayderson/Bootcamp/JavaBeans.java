package ati.nayderson.Bootcamp;

public class JavaBeans {
    
    public static void main(String[] args) {
        System.out.println("Talvez, aqui não tenha nada. Mas foi uma aula de Java Beans.");
    }
}
