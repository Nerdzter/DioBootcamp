package ati.nayderson.Bootcamp;

public class TiposDeVariaveis1 {
    
    public static void main(String[] args) {
        
        // int, string, boolean 


        int age = 18;
        final  String NAME = "Nayderson";
        String sex = "M";
        
        System.out.println("Oi, tudo bem? Meu nome é " + NAME + ", eu tenho " + age + "anos de idade.");
        System.out.println("Eu sou do sexo : " + sex);

        
        /* NUMÉRICOS
            -> BYTE
            -> SHORT
            -> INT --- MAIS USADO
            -> LONG 

          NUMÉRICOS COM FRACIONÁRIOS
            -> FLOAT
            -> DOUBLE --- MAIS USADO
               
        
          Como declarar ? 

          < TIPO > <NOME> = < VALOR ATRIBUIDO, OU NÃO>; 

          int age; 
          int fabricationDate = 2021;
          double moneyValue = 2500.67;
        
        */
    }
}
