package ati.nayderson.Bootcamp;

public class Métodos {
    // agora vamos aprender sobre Sintaxe, mais especificamente MÉTODOS

    boolean ligada = false;
    int canal = 1;
    int volume = 25;

    
}
